/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;

/**
 *
 * @author Cetecom
 */
public abstract class Contenido {
    
    protected String idContenido, contenidoRecomendado;

    public Contenido() {
    }

    public Contenido(String idContenido, String contenidoRecomendado) {
        this.idContenido = idContenido;
        this.contenidoRecomendado = contenidoRecomendado;
    }
    
    protected abstract void MostrarContenido();
    
  
    
}
