/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;

/**
 *
 * @author Cetecom
 */
public class Series extends Contenido implements CostoTotalSubSerie{
    
    
    private int cantidadTemporadas;
    private String estado, nombre;

    public Series() {
    }

    public Series(int cantidadTemporadas, String estado, String nombre, String idContenido, String contenidoRecomendado) {
        super(idContenido, contenidoRecomendado);
        this.cantidadTemporadas = cantidadTemporadas;
        this.estado = estado;
        this.nombre = nombre;
    }

    public int getCantidadTemporadas() {
        return cantidadTemporadas;
    }

    public void setCantidadTemporadas(int cantidadTemporadas) {
        this.cantidadTemporadas = cantidadTemporadas;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Series{" + "cantidadTemporadas=" + cantidadTemporadas + ", estado=" + estado + ", nombre=" + nombre + '}';
    }

   
    
    

    @Override
    protected void MostrarContenido() {
        System.out.println("Nombre: " + getNombre());
        System.out.println("Estado de la serie: " + getEstado());
        System.out.println("Cantidad de temporadas " + getCantidadTemporadas());
        
    }

    @Override
    public void CalcularTotalSeri() {
        int costoBase = 12000;
        int descuento = (int) (12000 * 0.8);
        int costototal = 12000 + descuento; 
    }
    
}
