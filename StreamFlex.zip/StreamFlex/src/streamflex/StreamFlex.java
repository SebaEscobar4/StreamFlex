/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package streamflex;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Cetecom
 */
public class StreamFlex {

   
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        
        
         Scanner Entrada = new Scanner(System.in);
         Usuario User = new Usuario();
         Peliculas Peli = new Peliculas();
         
         
         
         
         System.out.println(" -----Bienvenido a StreamFlex-----");
         System.out.println("Estos son los contenidos disponibles para ti...");
         System.out.println("[1]- Peliculas");
         System.out.println("[2]- Series");
         System.out.println("[3]- Documentales");
         System.out.println("[4]- Salir");
         
         int opcion = 0 ;
         
         int entrada = opcion;
         
         while (opcion !=4);
            switch (opcion){
                case 1: opcion = 1;
                    System.out.println("Estas son las peliculas disponibles para ti!!!");
                
                    break;
                    
                case 2 : opcion = 2;
                    System.out.println("Estan son las series disponibles para ti!!!");
                    break;
                    
                    
                case 3: opcion = 3;
                    System.out.println("Estos son los documentales disponibles!!!");
                    break;
            
            }
         
         
         
       
                 
            
         
         
         
         
         
         
         
       
    }

   
}
