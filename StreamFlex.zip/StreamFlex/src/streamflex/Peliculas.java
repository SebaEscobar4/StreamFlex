/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;



/**
 *
 * @author Cetecom
 */
public class Peliculas extends Contenido implements CostoTotalSubPelicula{
    
    private int duracion;
    private double calificacion;
    private String nombre;
    
    

    public Peliculas() {
    }

    public Peliculas(int duracion, double calificacion, String nombre, String idContenido, String contenidoRecomendado) {
        super(idContenido, contenidoRecomendado);
        this.duracion = duracion;
        this.calificacion = calificacion;
        this.nombre = nombre;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override 
    public String toString() {
        return "Peliculas{" + "duracion=" + duracion + ", calificacion=" + calificacion + ", nombre=" + nombre + '}';
    }
    
    protected void MostrarContenido() {
        
        System.out.println("Nombre " + getNombre());
        System.out.println("Nombre " + getCalificacion());
        System.out.println("Nombre " + getDuracion());
        
        
     
        
        
    }

    @Override
    public void CalcularTotalPeli() {
        int costoBase = 12000;
        int descuento = (int) (12000 * 0.10);
        int costototal = 12000 - descuento; 
    }

    

  
        
        
    

    



   
  
    
}
