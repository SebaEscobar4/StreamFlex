/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package streamflex;

/**
 *
 * @author Cetecom
 */
public class Documentales extends Contenido implements CostoTotalSubDocumental{
    
    
    private int duracion;
    private String nombre;

    public Documentales() {
    }

    public Documentales(int duracion, String nombre, String idContenido, String contenidoRecomendado) {
        super(idContenido, contenidoRecomendado);
        this.duracion = duracion;
        this.nombre = nombre;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Documentales{" + "duracion=" + duracion + ", nombre=" + nombre + '}';
    }

   
    

    @Override
    protected void MostrarContenido() {
        System.out.println("Nombre " + getNombre());
        System.out.println("Nombre " + getDuracion());
        
        
    }

    @Override
    public void CostoTotalSubDocu() {
        int costoBase = 12000;
        int descuento = (int) (12000 * 0.5);
        int costototal = 12000 - descuento; 
        
       
        
      
    }

   
    
}
